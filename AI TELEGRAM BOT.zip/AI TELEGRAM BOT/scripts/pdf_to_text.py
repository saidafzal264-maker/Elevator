import fitz
import os

PDF_DIR = "data/pdf"
TXT_DIR = "data/texts"

os.makedirs(TXT_DIR, exist_ok=True)

for pdf in os.listdir(PDF_DIR):
    if pdf.endswith(".pdf"):
        doc = fitz.open(os.path.join(PDF_DIR, pdf))
        text = ""
        for page in doc:
            text += page.get_text()
        with open(f"{TXT_DIR}/{pdf}.txt", "w", encoding="utf-8") as f:
            f.write(text)