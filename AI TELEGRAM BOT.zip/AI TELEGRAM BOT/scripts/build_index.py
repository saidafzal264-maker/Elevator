import faiss, json, os
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

texts = []
meta = []

for file in os.listdir("data/texts"):
    with open(f"data/texts/{file}", encoding="utf-8") as f:
        chunks = f.read().split("\n\n")
        for c in chunks:
            if len(c) > 300:
                texts.append(c)
                meta.append(file)

embeddings = model.encode(texts)
index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(embeddings)

faiss.write_index(index, "vector_db/faiss_index.bin")
json.dump(meta, open("vector_db/metadata.json", "w"))