import subprocess

def ask_llm(context, question):
    prompt = f"""
Sen texnik mutaxassissan.
Faqat berilgan matnga asoslanib javob ber.
Javobni O'ZBEK TILIDA yoz.

MATN:
{context}

SAVOL:
{question}
"""
    result = subprocess.run(
        ["ollama", "run", "qwen2.5:7b"],
        input=prompt,
        text=True,
        capture_output=True
    )
    return result.stdout