import faiss, json
from sentence_transformers import SentenceTransformer

index = faiss.read_index("vector_db/faiss_index.bin")
meta = json.load(open("vector_db/metadata.json"))
model = SentenceTransformer("all-MiniLM-L6-v2")

def search_context(query, top_k=3):
    q_emb = model.encode([query])
    D, I = index.search(q_emb, top_k)
    results = [meta[i] for i in I[0]]
    return "\n".join(results)